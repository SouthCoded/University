package comp0008;
/*
 * COMP0008 ReentrantLock - needs to be implemented.
 */

public class ReentrantLock {
	
	public ReentrantLock() {
		
	}
	
	public void lock() {
		
	}
	
	public void unlock() {
		
	}

}
