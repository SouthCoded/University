package comp0008;
/*
 * COMP0008 Semaphore - needs to be implemented.
 */

public class Semaphore {
	
	public Semaphore(int permits) {
		
	}
	
	public void acquire() {
		
	}
	
	public void release() {
		
	}

}
