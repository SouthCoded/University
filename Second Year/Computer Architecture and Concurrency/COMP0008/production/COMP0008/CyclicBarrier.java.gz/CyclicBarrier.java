package comp0008;
/*
 * COMP0008 CyclicBarrier - needs to be implemented.
 */

import java.util.concurrent.BrokenBarrierException;

public class CyclicBarrier {
	
	public CyclicBarrier(int count) {
		
	}
	
	public void await() throws BrokenBarrierException {
		
	}

}
