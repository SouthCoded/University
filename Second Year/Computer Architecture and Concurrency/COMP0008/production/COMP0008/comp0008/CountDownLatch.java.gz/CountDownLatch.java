package comp0008;
/*
 * COMP0008 CountDownLatch - needs to be implemented.
 */

public class CountDownLatch {
	
	public CountDownLatch(int count) {
		
	}
	
	public void countDown() {
		
	}
	
	public void await() {
		
	}

}
